import subprocess
import sys
import requests
import json
import zipfile
import shutil

def install_requirements():
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

try:
    import os
    import threading
    from tkinter import Tk, Label, Button, Entry, filedialog, StringVar, messagebox, Text, Scrollbar, END
    import tkinter as tk
    from tkinter import ttk
    import rawpy
    from PIL import Image
    import ttkbootstrap as tb
    from queue import Queue
except ImportError:
    install_requirements()
    import os
    import threading
    from tkinter import Tk, Label, Button, Entry, filedialog, StringVar, messagebox, Text, Scrollbar, END
    import tkinter as tk
    from tkinter import ttk
    import rawpy
    from PIL import Image
    import ttkbootstrap as tb
    from queue import Queue

class ARWToJPGConverter:
    def __init__(self, master):
        self.master = master
        master.title("RAW to Image Converter")
        master.geometry("700x600")
        self.style = tb.Style(theme="darkly")

        # Configure alert style
        self.style.configure('Alert.TFrame', background='yellow')
        self.style.configure('Alert.TLabel', background='yellow', foreground='black')

        self.alert_frame = tb.Frame(master, style='Alert.TFrame')
        self.alert_label = tb.Label(self.alert_frame, text="Update Available", font=("Helvetica", 12), style='Alert.TLabel')
        self.alert_button = tb.Button(self.alert_frame, text="Update Now", command=self.update_app, bootstyle="warning")
        self.alert_label.pack(side="left", padx=10)
        self.alert_button.pack(side="right", padx=10)
        self.alert_frame.pack(fill="x", pady=5)
        self.alert_frame.pack_forget()

        self.label = tb.Label(master, text="RAW to Image Converter Wizard", font=("Helvetica", 20), bootstyle="info")
        self.label.pack(pady=10)

        self.source_frame = tb.Frame(master)
        self.source_frame.pack(pady=5)
        self.source_label = tb.Label(self.source_frame, text="Source Folder:", font=("Helvetica", 12))
        self.source_label.pack(side='left', padx=5)
        self.source_entry = tb.Entry(self.source_frame, width=50)
        self.source_entry.pack(side='left', padx=5)
        self.source_button = tb.Button(self.source_frame, text="Select Source Folder", command=self.select_source_folder)
        self.source_button.pack(side='left', padx=5)

        self.target_frame = tb.Frame(master)
        self.target_frame.pack(pady=5)
        self.target_label = tb.Label(self.target_frame, text="Target Folder:", font=("Helvetica", 12))
        self.target_label.pack(side='left', padx=5)
        self.target_entry = tb.Entry(self.target_frame, width=50)
        self.target_entry.pack(side='left', padx=5)
        self.target_button = tb.Button(self.target_frame, text="Select Target Folder", command=self.select_target_folder)
        self.target_button.pack(side='left', padx=5)

        self.format_frame = tb.Frame(master)
        self.format_frame.pack(pady=5)
        self.format_label = tb.Label(self.format_frame, text="Target Format:", font=("Helvetica", 12))
        self.format_label.pack(side='left', padx=5)
        self.target_format = StringVar(value="jpg")
        self.format_dropdown = tb.Combobox(self.format_frame, textvariable=self.target_format, values=["jpg", "png", "tiff", "bmp"], state='readonly')
        self.format_dropdown.pack(side='left', padx=5)

        self.progress = tb.Progressbar(master, orient="horizontal", length=600, mode="determinate", style="info.Horizontal.TProgressbar")
        self.progress.pack(pady=20)

        self.status_var = StringVar()
        self.status_label = tb.Label(master, textvariable=self.status_var, font=("Helvetica", 12))
        self.status_label.pack(pady=5)

        self.log_text = Text(master, height=15, width=85, state='disabled', wrap='word', bg='#2b2b2b', fg='white')
        self.log_text.pack(pady=10)

        self.button_frame = tb.Frame(master)
        self.button_frame.pack(pady=10)

        self.convert_button = tb.Button(self.button_frame, text="Convert", command=self.start_conversion)
        self.convert_button.pack(side='left', padx=5)

        self.cancel_button = tb.Button(self.button_frame, text="Cancel", command=self.cancel_conversion, bootstyle="danger")
        self.cancel_button.pack(side='left')

        self.log_queue = Queue()
        self.master.after(100, self.update_log_text)

        self.style.configure("info.Horizontal.TProgressbar", troughcolor='#212121', bordercolor="black", relief="solid")

        self.conversion_thread = None
        self.cancel_flag = threading.Event()

        self.check_for_updates()

    def select_source_folder(self):
        folder = filedialog.askdirectory()
        self.source_entry.delete(0, 'end')
        self.source_entry.insert(0, folder)

    def select_target_folder(self):
        folder = filedialog.askdirectory()
        self.target_entry.delete(0, 'end')
        self.target_entry.insert(0, folder)

    def start_conversion(self):
        if self.conversion_thread is None or not self.conversion_thread.is_alive():
            self.cancel_flag.clear()
            self.conversion_thread = threading.Thread(target=self.convert_images)
            self.conversion_thread.start()

    def cancel_conversion(self):
        self.cancel_flag.set()
        if self.conversion_thread is not None and self.conversion_thread.is_alive():
            self.log_queue.put(("Conversion cancelled!", "red"))

    def convert_images(self):
        source_folder = self.source_entry.get()
        target_folder = self.target_entry.get()
        target_format = self.target_format.get()

        if not source_folder or not target_folder:
            messagebox.showerror("Error", "Please select both source and target folders.")
            return

        raw_files = [f for f in os.listdir(source_folder) if f.lower().endswith(('.arw', '.nef'))]
        num_files = len(raw_files)

        if num_files == 0:
            messagebox.showinfo("No Files", "No RAW files found in the selected source folder.")
            return

        self.progress["maximum"] = num_files

        for i, filename in enumerate(raw_files):
            if self.cancel_flag.is_set():
                break
            raw_path = os.path.join(source_folder, filename)
            target_path = os.path.join(target_folder, os.path.splitext(filename)[0] + f'.{target_format}')
            self.log_queue.put((f"Converting file: {filename}", "gray"))
            self.convert_raw_to_format(raw_path, target_path, target_format)
            self.progress["value"] = i + 1
            self.status_var.set(f"Converting {i + 1} of {num_files} files...")
            self.log_queue.put((f"Converted file: {filename}", "green"))
            self.master.update_idletasks()

        self.progress["value"] = 0
        self.status_var.set("Conversion complete!" if not self.cancel_flag.is_set() else "Conversion cancelled!")
        if not self.cancel_flag.is_set():
            self.log_queue.put(("Conversion complete!", "green"))
            messagebox.showinfo("Success", "All files have been converted successfully!")

    def convert_raw_to_format(self, raw_path, target_path, target_format):
        try:
            with rawpy.imread(raw_path) as raw:
                rgb = raw.postprocess()
                img = Image.fromarray(rgb)
                img.save(target_path, target_format.upper(), quality=95)
        except Exception as e:
            self.log_queue.put((f"Failed to convert {raw_path}: {e}", "red"))
            print(f"Failed to convert {raw_path}: {e}")

    def update_log_text(self):
        while not self.log_queue.empty():
            log_message, color = self.log_queue.get_nowait()
            self.log_text.config(state='normal')
            self.log_text.insert(END, log_message + "\n", color)
            self.log_text.tag_config(color, foreground=color)
            self.log_text.config(state='disabled')
            self.log_text.see(END)
        self.master.after(100, self.update_log_text)

    def check_for_updates(self):
        with open('release.json', 'r') as file:
            local_data = json.load(file)

        local_version = local_data["version"]
        auto_update = local_data["autoUpdate"] == "true"
        ask_for_updates = local_data["askForUpdates"] == "true"

        response = requests.get('https://capitalnerd.github.io/api/imageconverter/release.json')
        if response.status_code == 200:
            remote_data = response.json()
            latest_version = max(remote_data.keys())

            if latest_version > local_version:
                if auto_update:
                    self.log_queue.put(("Updating to the latest version...", "gray"))
                    self.download_and_install_update(remote_data[latest_version]["source"])
                elif ask_for_updates:
                    self.alert_frame.pack(fill="x", pady=5)

    def download_and_install_update(self, url):
        self.log_queue.put(("Downloading update...", "gray"))
        response = requests.get(f'https://capitalnerd.github.io/api/imageconverter/{url}')
        with open('update.zip', 'wb') as file:
            file.write(response.content)
        with zipfile.ZipFile('update.zip', 'r') as zip_ref:
            zip_ref.extractall('update')
        for item in os.listdir('update'):
            s = os.path.join('update', item)
            d = os.path.join('.', item)
            if os.path.isdir(s):
                if os.path.exists(d):
                    shutil.rmtree(d)
                shutil.move(s, d)
            else:
                shutil.move(s, d)
        os.remove('update.zip')
        shutil.rmtree('update')
        self.log_queue.put(("Update installed. Restart the application.", "green"))
        messagebox.showinfo("Update", "Update installed. Restart the application.")

    def update_app(self):
        response = requests.get('https://capitalnerd.github.io/api/imageconverter/release.json')
        if response.status_code == 200:
            remote_data = response.json()
            latest_version = max(remote_data.keys())
            self.download_and_install_update(remote_data[latest_version]["source"])

if __name__ == "__main__":
    root = tk.Tk()
    app = ARWToJPGConverter(root)
    root.mainloop()
